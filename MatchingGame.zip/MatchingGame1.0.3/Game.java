import java.util.*;
import javax.swing.*;
import java.awt.*;
/**
 * This is the main class. It pretty much serves to run the 
 * whole program. The math for a 4/4 grid does not check out the
 * same way the math for a 6/6 grid would so at the moment
 * the game is built for a 4/4 grid style of play.
 *
 * @author Trey Castrechino
 * @version 1.0.3
 */
public class Game
{
    final int NUMCARDS ;

    public static void main(){
        final int NUMCARDS = 8;
        Game g = new Game(NUMCARDS);
        Doubles d = new Doubles(NUMCARDS);
        CardLocations l = new CardLocations(NUMCARDS);
        l.initializeCards(d.k);
        Drawer draw = new Drawer(l);

    }

    public Game(int numCards){
        this.NUMCARDS = numCards;
    }

}
