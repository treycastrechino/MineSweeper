import java.util.*;
import javax.swing.*;
import java.awt.*;

/**
 * This class is an object where cards are "stored" on the 
 * game board.They are rectangles to make method creation a
 * bit easier.
 *
 */
public class CardSpace extends Rectangle
{  
    private Card myCard;
    private Card cardBack = new Card(14,1);
    private boolean hasCard = false;
    private boolean faceDown = false;
    public CardSpace(int x, int y, int width, int height){
        this.x=x;
        this.y=y;
        this.width=width;
        this.height=height;
    }
    /**
     * this will flip the current card in the space
     * 
     */
    public void flipCard(){
        this.faceDown = !this.faceDown;
    }
    /**
     * this will set this card space's card to be any input card
     * 
     */
    public void setCard(Card a){
        this.myCard=a;
        this.hasCard = true;
    }
    /**
     * this will set the card spaces card to be face down
     * 
     */
    public void setDown(){
        this.faceDown= true;
    }
    /**
     * This method checks to see if the card in the card space
     * is face up.
     */
    public boolean isFaceUp(){
        if(this.faceDown==true){
            return false;
        }
        else{
            return true;
        }
    }
    /**
     * this will check if the card space is empty or not
     * 
     */
    public boolean hasCard(){
        return hasCard;
    }
    /**
     * This method "removes" the card from the space so that it
     * will not be drawn when redraw is called or if asked
     * is there a card at that location by the mouse
     */
    public void removeCard(){
        this.hasCard = false;
    }
    /**
     * this will return different cards to the drawer because
     * facedown is stored as a seperate card.
    */
    public Card getCard(){
        
            if(faceDown==true){
                return cardBack;
            }
            else{
                return myCard;
            }
        }
     
    /**
     * This method is used to check if the face up cards are 
     *equal so they can be removed or put back face down.
     */
    public boolean testEqual(CardSpace s){
        boolean isEqual = false;
        if(this.getCard().equals(s.getCard())){
            isEqual = true;
        }
        return isEqual;
    }
}
