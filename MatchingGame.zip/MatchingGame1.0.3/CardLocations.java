import java.util.*;
import javax.swing.*;
import java.awt.*;
/**
 * CardLocations is the two dimensional array that holds
 * all the CardSpaces that will populate the game.
 * It is also known as the game state. The descisions made during
 * the game will be based on the state of this array of CardSpaces.
 *
 * 
 */
public class CardLocations
{
    CardSpace[][] state;
    Images i;
    int score=0;
    boolean gameover=false;
    int pairsFound =0;
    int numCards;
    int cardWidth;
    int cardHeight;
    int totalFaceUp;
    CardSpace[] testCards = new CardSpace[2];
    public CardLocations(int numCards){
        this.numCards=numCards;
        i = new Images();
        cardWidth=i.cardWidth;
        cardHeight=i.cardHeight;
        state = new CardSpace[numCards/2][numCards/2];
        makeSpaces();
        allDown();
    }
    /**
     * This fills the CardLocations each with a CardSpace object
     */
    public void makeSpaces(){
        for(int i = 0; i<state[0].length;i++){ 
            for(int j = 0; j<state[1].length;j++){
                int tempx = (j+1)*100;
                int tempy = (i+1)*100;
                CardSpace f = new CardSpace(tempx,tempy,cardWidth,cardHeight);
                state[i][j]=f;
            }
        }
    }
    /**
     * This method gives each CardSpace a new Card to hold in
     * that space
     */
    public void initializeCards(Card[][] x){
        int row = state[0].length;
        int col = state[1].length;
        for(int i = 0; i<row;i++){
            for(int j = 0; j<col;j++){
                state[i][j].setCard(x[i][j]);
            }
        }
    }
    /**
     * This method will set each card in the game to face down
     */
    public void allDown(){
        totalFaceUp=0;
        int row = state[0].length;
        int col = state[1].length;
        for(int i = 0; i<row;i++){
            for(int j = 0; j<col;j++){
                state[i][j].setDown();
                
            }
        }
    }
    /**
     * This method checks each CardSpace in the array just like
     * most methods. It then checks to see if the card in that
     * CardSpace is face up and if so removes that card
     * from that CardSpace
     */
    public void removeFaceUp(){
        int row = state[0].length;
        int col = state[1].length;
        for(int i = 0; i<row;i++){
            for(int j = 0; j<col;j++){
                if(state[i][j].isFaceUp()){
                    state[i][j].removeCard();
                }
            }
        }
        allDown();
    }
    /**
     * This method will update the placeholder spots for faceup
     * cards. There should only ever be 2 cards face up and when
     * this method is given a cardspace with a face up card it
     * stores that later to test the placeholder spots for 
     * equality and then if equal remove the original cards
     * or put them face down.
     */
    public void updateFaceUp(CardSpace s){
        if(totalFaceUp==0){
            testCards[0]=s;
            return;
        }
        if(totalFaceUp==1){
            testCards[1]=s;
            return;
        }
    }
    /**
     * this method will test the cards in two card locations
     * in the game when total face up cards ==2. Then if they are
     * equal will remove all face up cards(which is only the two
     * we need). Otherwise set all cards down. If the pair was 
     * unsuccesful you will lose points, otherwise gain points.
     */
    public void testDouble(){
          if(totalFaceUp==2){
            if(testCards[0].testEqual(testCards[1])){
                removeFaceUp();
                pairsFound++;
                updateScore(true);
            }
            else{
                allDown();
                updateScore(false);
            }
        }
    }
    /**
     * This is a method that will update the score based on a sucess
     * or failure on finding a double. A fail is returned as false
     * and success returned as true.
     */
    public int updateScore(boolean f){
        if(f==false){
            score = score-10;
        }
        else{
            score = score+100;
        }
        return score;
    }
    /**
     * this method at the moment controls the "win screen". The
     * game can not be lost, so it only has a true or false to 
     * see if you finished or not. When you match all the cards
     * on the screen you win the game. 
     */
    public boolean gameWon(){
        if(pairsFound==numCards){
            return true;
        }
        else{
            return false;
        }
    }
    
}

