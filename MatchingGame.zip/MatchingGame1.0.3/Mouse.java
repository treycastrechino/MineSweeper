import java.awt.event.*;
import java.awt.*;
/**
 * This class creates the mouse listener so it can be added
 * to the canvas to tell the game when things are clicked
 * to act accordingy. It needs a new drawer because the drawer
 * has the method that interacts with the screen and redraws 
 * things.
 *
 * 
 */
public class Mouse extends MouseAdapter
{
   Drawer d;
   public Mouse(Drawer d){
       this.d=d;
    }
   @Override 
   public void mouseClicked(MouseEvent e){
       d.ifClicked(e.getPoint());
    }
    
}
