import java.util.*;
import javax.swing.*;
import java.awt.*;
/**
 * This class repaints the screen at construction and 
 * when the screen is clicked.
 *
 */
public class Drawer extends Canvas
{
    CardLocations l;
    int numCards;
    public Drawer(CardLocations l){
        this.numCards=l.numCards;
        this.l= l;
        setBackground(new Color(0x088A4B)); // green
        setSize(600,600);
        JFrame frame = new JFrame("Matching Game!");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(this);
        Mouse m = new Mouse(this);
        this.addMouseListener(m);
        frame.pack();
        frame.setVisible(true);
    }

    /**
     * this method draws the cards at a location
     * the newx,newy garbage is because image wants ints
     * but rectangles return doubles
    */
    public void drawCardAt(Graphics g, Card card, double x,double y) {
        int rank = card.getRank();
        int suit = card.getSuit();
        int newx = (int)x;
        int newy = (int)y;
        Image image = l.i.images[rank][suit];
        g.drawImage(image,newx,newy,null);
    }
    /**
     * this is the paint method. it knows the cardspace array and
     * will check if a card is still in the play area and then draw
     * the screen on update.
    */
    public void paint(Graphics g){
        String score="Score: "+l.score;
        g.drawString(score,280,20);
        int row = l.state[0].length;
        int col = l.state[1].length;
        for(int i = 0; i<row;i++){
            for(int j = 0; j<col;j++){
                if((l.state[i][j].hasCard() ==true)){
                    drawCardAt(g,l.state[i][j].getCard(),l.state[i][j].getX(),l.state[i][j].getY());
                }
            }
        }
    }
    /**
     * This method is ran by the mouse everytime a point on the
     * canvas is clicked.It checks first if the point clicked
     * belongs to any cardspaces in the array. Then if the card
     * contained is face down(because we don't want to update if
     * a face up card is clicked), and if there is a card at that
     * location. The last test is if the game is won to update
     * the screen.
     */
    public void ifClicked(Point p){
        l.testDouble();
        int row = l.state[0].length;
        int col = l.state[1].length;
        for(int i = 0; i<row;i++){
            for(int j = 0; j<col;j++){
                if(l.state[i][j].contains(p) && !l.state[i][j].isFaceUp() && l.state[i][j].hasCard()) {
                    if(l.totalFaceUp<2){ 
                        l.state[i][j].flipCard();
                        l.updateFaceUp(l.state[i][j]);
                        l.totalFaceUp=l.totalFaceUp+1;
                    }
                    
                }
                
            }
        }
        repaint();
        if(l.gameWon()){
            bigParty();
        }
    }
    /**
     * This is a placeholder method that should eventually have
     * graphics and maybe sounds to really give the player
     * a sense of satisfaction for winning.
     */
    public void bigParty(){
        setBackground(new Color(255,255,255));
    }
}
