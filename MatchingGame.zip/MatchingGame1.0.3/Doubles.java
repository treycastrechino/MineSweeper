import java.util.*;
/**
 * This class will create a random set of doubles for the number
 * of cards specified. If you say you want 8 cards, it will
 * return two dimentional card array of 8 doubles of random cards
 * for a total of 16 cards.
 */
public class Doubles
{
    public Card[][] k;
    Random rand = new Random();
    private ArrayList<Card> cardPool;
    private Card[] smallPool;
    int numCards;

    public Doubles(int numCards)
    {   
        this.numCards = numCards;
        this.cardPool = new ArrayList<Card>();
        this.smallPool=new Card[numCards];
        k= new Card[numCards/2][numCards/2];
        makePool();
        shufflePool();
        makeSmallPool(cardPool);
        k= makeDoubles(smallPool);
        shuffleDoubles();
    }
    /**
     * this method creates a pool of 52 different cards
     * 
     */
    public void makePool(){
        for (int suit = 0; suit <= 3; suit++) {
            for (int rank = 1; rank <= 13; rank++) {
                Card add = new Card(rank,suit);
                cardPool.add(add);
            }
        }
    }
    /**
     * this method makes a new card pool, the size of number of cards
     * 
     */
    public void makeSmallPool(ArrayList<Card> y){
        for(int i = 0;i<numCards;i++){
            smallPool[i]=y.get(i);
        }
    }
    /**
     * this returns the completed double card array
     * 
     */
    public Card[][] returnDouble(){
        return k;
    }
    /**
     * this method takes the small list of cards and makes it 
     * into doubles
     * 
     */
    public Card[][] makeDoubles(Card[] x){
        int totalCards = numCards*2;
        int cardCount=0;
        for(int i = 0; i<k[0].length;i++){

            for(int j = 0; j<k[1].length;j=j+2){
                for(int t = 0;t<2;t++){
                    k[i][j+t] = x[cardCount];
                }
                if(cardCount<numCards){
                    cardCount=cardCount+1;
                }
            }
        }
        return k;
    }
    /**
     * this shuffles up the 52 pool of cards so the first x
     * will be random before they are used for doubles
    */
    public void shufflePool() {
        Random random = new Random();
        for (int i = cardPool.size() - 1; i > 0; i--) {
            int j = random.nextInt(i);
            swapCards(i, j);
        }
    }
    /**
     * this is the swap method that shufflePool uses
     * 
     */
    public void swapCards(int i, int j) {
        Card temp = cardPool.get(i);
        cardPool.set(i, cardPool.get(j));
        cardPool.set(j, temp);
    }
    /**
     * this method will swap the doubles in the 2d array
     * the same way that swap cards works
     */
    public void swapDoubles(int i,int j,int a,int b){
        Card temp = k[i][j];
        k[i][j]=k[a][b];
        k[a][b]=temp;

    }
    /**
     * this method shuffles all the doubles using the swap doubles
     * similar to shufflePool
     */
    public void shuffleDoubles(){
        Random random = new Random();
        for(int i = 0; i<k[0].length;i++){
            for(int j = 0; j<k[1].length;j++){
                int a = random.nextInt(k[0].length);
                int b = random.nextInt(k[1].length);
                swapDoubles(i, j,a,b);

            }
        }
    }

}
