import java.util.*;
import javax.swing.*;
import java.awt.*;
/**
 * This class is a storage spot for all the images the game
 * and other classes will have to use.
 */
public class Images
{
    public Image[][] images;
    public int cardWidth, cardHeight;
    final String CARDSET ="cardset-oxymoron";
    char [] suits = {'c','d','h','s'};
    
    public Images(){
        loadImages();
        cardWidth = images[1][1].getWidth(null);
        cardHeight = images[1][1].getHeight(null);
        String cardset = "cardset-oxymoron";
    }
    
    public int getWidth(){
        return cardWidth;
    }
    
    public int getHeight(){
        return cardHeight;
    }
    
    /**
     * loads the images into a 2d array for rank suit and
     * card back
     */
    private void loadImages () {
        images = new Image[15][4];
        for (int suit = 0; suit <= 3; suit++) {
            char c = suits[suit];
            for (int rank = 1; rank <= 14; rank++) {
                if(rank<=13){
                    String s = String.format("%s/%02d%c.gif",CARDSET, rank, c);
                    images[rank][suit] = new ImageIcon(s).getImage();
                }
                else{
                    String s = CARDSET+"/back001.gif";
                    images[rank][suit] = new ImageIcon(s).getImage();
                }
            }
        }
    }
}
